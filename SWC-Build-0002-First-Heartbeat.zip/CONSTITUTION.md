# SWC Constitution

1. Safety before comfort.
2. Local before cloud.
3. Explainable decisions.
