# Changelog

## 0.1.0-dev002
- Initial project structure
- Core architecture created
