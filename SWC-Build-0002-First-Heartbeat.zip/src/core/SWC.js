function main(){print("SWC Build 0002");}
main();
