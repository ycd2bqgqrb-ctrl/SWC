# Vision

Build a reliable local weather automation platform for Shelly.
