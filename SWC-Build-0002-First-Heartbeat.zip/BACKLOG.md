# Backlog

- BLE WS90 integration
- Rule Engine
- Safe Mode
