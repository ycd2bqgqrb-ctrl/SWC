# Shelly Weather Controller

Version: 0.1.0-dev002
Build: 0002 - First Heartbeat
