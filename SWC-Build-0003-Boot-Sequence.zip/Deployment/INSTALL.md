# INSTALL

1. Script öffnen
2. Inhalt von SWC.js einfügen
3. Speichern und starten
