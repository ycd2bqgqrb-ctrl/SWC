/******************************************************************************
 * Shelly Weather Controller
 * Version : 0.1.0-dev003
 * Build   : 0003
 * Name    : Boot Sequence
 ******************************************************************************/

let SYSTEM={
  name:"Shelly Weather Controller",
  version:"0.1.0-dev003",
  build:"0003",
  codename:"Boot Sequence"
};

let STATE={
  lifecycle:"BOOT",
  initialized:false
};

let Logger={
  info:function(module,msg){
    print("[INFO ] ["+module+"] "+msg);
  }
};

let Boot={
  start:function(){
    Logger.info("SYSTEM","========================================");
    Logger.info("SYSTEM",SYSTEM.name);
    Logger.info("SYSTEM","Version : "+SYSTEM.version);
    Logger.info("SYSTEM","Build   : "+SYSTEM.build);
    Logger.info("SYSTEM","Codename: "+SYSTEM.codename);
    Logger.info("SYSTEM","Boot startet");
    STATE.lifecycle="INITIALIZING";
    STATE.initialized=true;
    STATE.lifecycle="RUNNING";
    Logger.info("SYSTEM","Status  : "+STATE.lifecycle);
    Logger.info("SYSTEM","SWC lebt.");
    Logger.info("SYSTEM","========================================");
  }
};

function main(){
  Boot.start();
}

main();
