Build 0003 First runnable core.
