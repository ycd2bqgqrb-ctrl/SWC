var SWCLogger = (function () {
  var LEVELS = {
    DEBUG: 10,
    INFO: 20,
    WARN: 30,
    ERROR: 40,
    FATAL: 50
  };

  function levelName(level) {
    var names = ["DEBUG", "INFO", "WARN", "ERROR", "FATAL"];
    return names[(level / 10) - 1] || "INFO";
  }

  function normalizeLevel(level) {
    if (typeof level === "number") return level;
    var name = String(level || "INFO").toUpperCase();
    return LEVELS[name] || LEVELS.INFO;
  }

  function safeJson(value) {
    if (value === undefined) return "";
    if (value === null) return "null";
    if (value instanceof Error) {
      return JSON.stringify({
        name: value.name,
        message: value.message
      });
    }
    try {
      return JSON.stringify(value);
    } catch (e) {
      return "[Unserializable]";
    }
  }

  function write(line) {
    if (typeof print === "function") {
      print(line);
    } else if (typeof console !== "undefined" &&
               typeof console.log === "function") {
      console.log(line);
    }
  }

  function Logger(options) {
    options = options || {};
    this.name = options.name || "SWC";
    this.context = options.context || "";
    this.minLevel = normalizeLevel(options.minLevel || "INFO");
  }

  Logger.prototype.setLevel = function (level) {
    this.minLevel = normalizeLevel(level);
  };

  Logger.prototype.child = function (context) {
    var child = new Logger({
      name: this.name,
      context: this.context
        ? this.context + ":" + context
        : String(context),
      minLevel: this.minLevel
    });
    return child;
  };

  Logger.prototype.log = function (level, message, data, code) {
    var numeric = normalizeLevel(level);
    if (numeric < this.minLevel) return false;

    var text;
    if (message instanceof Error) {
      text = message.message;
    } else if (typeof message === "string") {
      text = message;
    } else {
      text = safeJson(message);
    }

    var parts = [
      "[" + new Date().toISOString() + "]",
      "[" + levelName(numeric) + "]"
    ];

    if (this.context) parts.push("[" + this.context + "]");
    if (code) parts.push("[" + code + "]");

    parts.push(text);

    if (data !== undefined) {
      var json = safeJson(data);
      if (json) parts.push(json);
    }

    write(parts.join(" "));
    return true;
  };

  Logger.prototype.debug = function (message, data, code) {
    return this.log("DEBUG", message, data, code);
  };

  Logger.prototype.info = function (message, data, code) {
    return this.log("INFO", message, data, code);
  };

  Logger.prototype.warn = function (message, data, code) {
    return this.log("WARN", message, data, code);
  };

  Logger.prototype.error = function (message, data, code) {
    return this.log("ERROR", message, data, code);
  };

  Logger.prototype.fatal = function (message, data, code) {
    return this.log("FATAL", message, data, code);
  };

  return Logger;
})();
