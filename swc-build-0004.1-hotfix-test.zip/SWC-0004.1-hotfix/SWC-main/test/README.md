# Hardware Test

Do not run the previous Node.js version of `Logger.test.js` on SWC-LAB-01.

The Shelly runtime does not provide Node.js `require()`. Use the
`test/Logger.test.js` from this hotfix package. It is self-contained and
uses the Shelly `print()` API.
