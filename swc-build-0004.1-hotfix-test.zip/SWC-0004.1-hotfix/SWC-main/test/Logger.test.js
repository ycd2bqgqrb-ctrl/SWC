/*
 * SWC Build 0004.1
 * Shelly-compatible hardware test.
 *
 * IMPORTANT:
 * Shelly Script does not provide Node.js CommonJS require().
 * Therefore this test is intentionally self-contained.
 */

var SWCLogger = (function () {
  var LEVELS = {
    DEBUG: 10,
    INFO: 20,
    WARN: 30,
    ERROR: 40,
    FATAL: 50
  };

  function normalizeLevel(level) {
    if (typeof level === "number") return level;
    return LEVELS[String(level || "INFO").toUpperCase()] || LEVELS.INFO;
  }

  function json(value) {
    if (value === undefined) return "";
    if (value === null) return "null";
    try { return JSON.stringify(value); }
    catch (e) { return "[Unserializable]"; }
  }

  function Logger(options) {
    options = options || {};
    this.context = options.context || "";
    this.minLevel = normalizeLevel(options.minLevel || "INFO");
  }

  Logger.prototype.log = function (level, message, data, code) {
    var n = normalizeLevel(level);
    if (n < this.minLevel) return false;

    var names = ["DEBUG", "INFO", "WARN", "ERROR", "FATAL"];
    var line = "[" + new Date().toISOString() + "] " +
      "[" + names[(n / 10) - 1] + "] ";

    if (this.context) line += "[" + this.context + "] ";
    if (code) line += "[" + code + "] ";

    line += typeof message === "string" ? message : json(message);

    if (data !== undefined) line += " " + json(data);

    print(line);
    return true;
  };

  Logger.prototype.debug = function (m, d, c) { return this.log("DEBUG", m, d, c); };
  Logger.prototype.info  = function (m, d, c) { return this.log("INFO",  m, d, c); };
  Logger.prototype.warn  = function (m, d, c) { return this.log("WARN",  m, d, c); };
  Logger.prototype.error = function (m, d, c) { return this.log("ERROR", m, d, c); };
  Logger.prototype.fatal = function (m, d, c) { return this.log("FATAL", m, d, c); };

  return Logger;
})();

var passed = 0;
var failed = 0;

function assert(name, condition) {
  if (condition) {
    passed++;
    print("PASS: " + name);
  } else {
    failed++;
    print("FAIL: " + name);
  }
}

print("SWC Build 0004.1 - Logger 2.0 hardware test");
print("Runtime: Shelly Script");
print("------------------------------------------");

var logger = new SWCLogger({
  context: "TEST",
  minLevel: "INFO"
});

assert("DEBUG filtered", logger.debug("hidden") === false);
assert("INFO accepted", logger.info("hello", { ok: true }, "T-001") === true);
assert("WARN accepted", logger.warn("warning", undefined, "T-002") === true);
assert("ERROR accepted", logger.error("error", undefined, "T-003") === true);
assert("FATAL accepted", logger.fatal("fatal", undefined, "T-004") === true);

print("------------------------------------------");
print("RESULT: " + passed + " passed, " + failed + " failed");

if (failed === 0) {
  print("BUILD 0004.1 LOGGER TEST: PASS");
} else {
  print("BUILD 0004.1 LOGGER TEST: FAIL");
}
