# SWC
Shelly Weather Controller

## Build 0004.1-hotfix

The first hardware test exposed a Node.js/CommonJS incompatibility:
`require()` is not available in the Shelly Script runtime.

This package removes that dependency from the hardware test and provides a
Shelly-compatible Logger 2.0 implementation.

Run:

`test/Logger.test.js`

Expected final line:

`BUILD 0004.1 LOGGER TEST: PASS`
