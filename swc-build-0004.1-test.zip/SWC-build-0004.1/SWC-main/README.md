# SWC
Shelly Weather Controller

## Build 0004.1
Foundation-Core with Logger 2.0.

### Runtime
The code is written as dependency-free JavaScript and is intended to run in a
Shelly scripting environment. `src/main.js` is the hardware smoke-test entry point.

### Logger 2.0
- DEBUG / INFO / WARN / ERROR / FATAL
- ISO timestamps
- optional context
- optional error codes
- structured records
- configurable minimum log level
- safe serialization of objects and errors
- output through `print()` when available, otherwise `console.log()`

### Hardware smoke test
Run `src/main.js` as the first SWC script on the target Shelly device.
