const assert = require("assert");
const Logger = require("../src/foundation/logger/Logger");

const lines = [];
const logger = new Logger({
  name: "TEST",
  context: "UNIT",
  minLevel: "INFO",
  writer: function (line) {
    lines.push(line);
  }
});

assert.strictEqual(logger.debug("hidden"), false);
assert.strictEqual(lines.length, 0);

assert.strictEqual(logger.info("hello", { ok: true }, "T-001"), true);
assert.strictEqual(lines.length, 1);
assert.ok(lines[0].indexOf("[INFO]") !== -1);
assert.ok(lines[0].indexOf("[UNIT]") !== -1);
assert.ok(lines[0].indexOf("[T-001]") !== -1);
assert.ok(lines[0].indexOf("hello") !== -1);
assert.ok(lines[0].indexOf('{"ok":true}') !== -1);

const child = logger.child("HW");
child.warn("warning");
assert.ok(lines[1].indexOf("[UNIT:HW]") !== -1);

console.log("Logger 2.0 tests passed.");
