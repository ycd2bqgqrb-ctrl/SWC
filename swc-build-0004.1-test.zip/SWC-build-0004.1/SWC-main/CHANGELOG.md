# Changelog

## 0004.1
- Added Foundation-Core logger.
- Added Logger 2.0 levels, context and error codes.
- Added configurable output writer.
- Added host unit smoke test.
- Added Shelly hardware smoke-test entry point.
