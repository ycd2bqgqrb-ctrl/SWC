const LEVELS = Object.freeze({
  DEBUG: 10,
  INFO: 20,
  WARN: 30,
  ERROR: 40,
  FATAL: 50
});

const LEVEL_NAMES = Object.freeze({
  10: "DEBUG",
  20: "INFO",
  30: "WARN",
  40: "ERROR",
  50: "FATAL"
});

function normalizeLevel(level) {
  if (typeof level === "number") {
    if (LEVEL_NAMES[level]) return level;
    throw new Error("Unknown numeric log level: " + level);
  }

  const name = String(level || "INFO").toUpperCase();
  if (LEVELS[name] !== undefined) return LEVELS[name];

  throw new Error("Unknown log level: " + level);
}

module.exports = {
  LEVELS: LEVELS,
  LEVEL_NAMES: LEVEL_NAMES,
  normalizeLevel: normalizeLevel
};
