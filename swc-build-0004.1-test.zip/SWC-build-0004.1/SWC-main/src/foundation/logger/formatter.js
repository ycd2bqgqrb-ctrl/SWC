function safeJson(value) {
  if (value === undefined) return "";
  if (value === null) return "null";

  if (value instanceof Error) {
    return JSON.stringify({
      name: value.name,
      message: value.message,
      stack: value.stack
    });
  }

  try {
    return JSON.stringify(value);
  } catch (_) {
    return "[Unserializable]";
  }
}

function formatRecord(record) {
  const parts = [
    "[" + record.timestamp + "]",
    "[" + record.level + "]"
  ];

  if (record.context) parts.push("[" + record.context + "]");

  if (record.code) parts.push("[" + record.code + "]");

  parts.push(record.message);

  if (record.data !== undefined) {
    const data = safeJson(record.data);
    if (data) parts.push(data);
  }

  return parts.join(" ");
}

module.exports = {
  safeJson: safeJson,
  formatRecord: formatRecord
};
