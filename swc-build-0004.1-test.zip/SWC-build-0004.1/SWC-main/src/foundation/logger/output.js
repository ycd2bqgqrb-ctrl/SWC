function defaultWriter(line) {
  if (typeof print === "function") {
    print(line);
    return;
  }

  if (typeof console !== "undefined" && typeof console.log === "function") {
    console.log(line);
    return;
  }

  throw new Error("No logger output function available");
}

function createOutput(writer) {
  const target = typeof writer === "function" ? writer : defaultWriter;

  return {
    write: function (line) {
      target(line);
    }
  };
}

module.exports = {
  createOutput: createOutput
};
