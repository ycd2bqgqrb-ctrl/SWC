const levels = require("./levels");
const formatter = require("./formatter");
const output = require("./output");

function isoNow() {
  return new Date().toISOString();
}

function normalizeMessage(message) {
  if (message instanceof Error) return message.message;
  if (typeof message === "string") return message;

  try {
    return JSON.stringify(message);
  } catch (_) {
    return String(message);
  }
}

function Logger(options) {
  options = options || {};

  this.name = options.name || "SWC";
  this.context = options.context || "";
  this.minLevel = levels.normalizeLevel(options.minLevel || "DEBUG");
  this.output = output.createOutput(options.writer);
}

Logger.prototype.setLevel = function (level) {
  this.minLevel = levels.normalizeLevel(level);
};

Logger.prototype.child = function (context) {
  const childContext = this.context
    ? this.context + ":" + context
    : String(context);

  return new Logger({
    name: this.name,
    context: childContext,
    minLevel: this.minLevel,
    writer: this.output.write
  });
};

Logger.prototype.log = function (level, message, data, code) {
  const numericLevel = levels.normalizeLevel(level);

  if (numericLevel < this.minLevel) return false;

  const record = {
    timestamp: isoNow(),
    level: levels.LEVEL_NAMES[numericLevel],
    logger: this.name,
    context: this.context,
    code: code || "",
    message: normalizeMessage(message)
  };

  if (data !== undefined) record.data = data;

  this.output.write(formatter.formatRecord(record));
  return true;
};

Logger.prototype.debug = function (message, data, code) {
  return this.log("DEBUG", message, data, code);
};

Logger.prototype.info = function (message, data, code) {
  return this.log("INFO", message, data, code);
};

Logger.prototype.warn = function (message, data, code) {
  return this.log("WARN", message, data, code);
};

Logger.prototype.error = function (message, data, code) {
  return this.log("ERROR", message, data, code);
};

Logger.prototype.fatal = function (message, data, code) {
  return this.log("FATAL", message, data, code);
};

module.exports = Logger;
