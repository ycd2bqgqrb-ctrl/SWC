const Logger = require("./foundation/logger/Logger");

const logger = new Logger({
  name: "SWC",
  context: "BOOT",
  minLevel: "DEBUG"
});

logger.info("SWC Build 0004.1 starting", undefined, "BOOT-0001");
logger.debug("Logger 2.0 initialized", {
  levels: ["DEBUG", "INFO", "WARN", "ERROR", "FATAL"]
}, "LOG-0001");

logger.warn("Hardware smoke test is running", undefined, "TEST-0001");

try {
  if (typeof Shelly !== "undefined") {
    logger.info("Shelly runtime detected", undefined, "HW-0001");
  } else {
    logger.warn("Shelly runtime not detected; running host smoke test", undefined, "HW-0002");
  }

  logger.info("SWC Build 0004.1 boot test passed", undefined, "BOOT-0002");
} catch (error) {
  logger.error(error, undefined, "BOOT-ERR-001");
}
