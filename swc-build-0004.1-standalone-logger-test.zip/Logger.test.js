var LEVELS={DEBUG:10,INFO:20,WARN:30,ERROR:40,FATAL:50};
var NAMES={10:"DEBUG",20:"INFO",30:"WARN",40:"ERROR",50:"FATAL"};
function level(v){if(typeof v==="number")return NAMES[v]?v:20;return LEVELS[String(v||"INFO").toUpperCase()]||20;}
function json(v){if(v===undefined)return "";if(v===null)return "null";try{return JSON.stringify(v);}catch(e){return "[Unserializable]";}}
function Logger(o){o=o||{};this.context=o.context||"";this.minLevel=level(o.minLevel||"INFO");}
Logger.prototype.log=function(l,m,d,c){var n=level(l);if(n<this.minLevel)return false;var s="["+new Date().toISOString()+"] ["+NAMES[n]+"] ";if(this.context)s+="["+this.context+"] ";if(c)s+="["+c+"] ";s+=typeof m==="string"?m:json(m);if(d!==undefined)s+=" "+json(d);print(s);return true;};
Logger.prototype.debug=function(m,d,c){return this.log("DEBUG",m,d,c);};
Logger.prototype.info=function(m,d,c){return this.log("INFO",m,d,c);};
Logger.prototype.warn=function(m,d,c){return this.log("WARN",m,d,c);};
Logger.prototype.error=function(m,d,c){return this.log("ERROR",m,d,c);};
Logger.prototype.fatal=function(m,d,c){return this.log("FATAL",m,d,c);};
var passed=0,failed=0;
function test(n,c){if(c){passed++;print("PASS: "+n);}else{failed++;print("FAIL: "+n);}}
print("SWC Build 0004.1 - Standalone Logger 2.0 test");
print("Runtime: Shelly Script");
print("-----------------------------------------------");
test("Shelly runtime detected",typeof Shelly!=="undefined");
var logger=new Logger({context:"TEST",minLevel:"INFO"});
test("DEBUG filtered",logger.debug("hidden")===false);
test("INFO accepted",logger.info("info",undefined,"T-001")===true);
test("WARN accepted",logger.warn("warn",undefined,"T-002")===true);
test("ERROR accepted",logger.error("error",undefined,"T-003")===true);
test("FATAL accepted",logger.fatal("fatal",undefined,"T-004")===true);
print("-----------------------------------------------");
print("RESULT: "+passed+" passed, "+failed+" failed");
print(failed===0?"BUILD 0004.1 LOGGER TEST: PASS":"BUILD 0004.1 LOGGER TEST: FAIL");
