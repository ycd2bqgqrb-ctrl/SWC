# SWC — Build 0004.1

Logger 2.0 is now integrated into a single Shelly-compatible runtime file.

## Hardware test

1. Run `src/swc-0004.1.js`.
2. Run `test/Logger.test.js`.

Expected result:

`BUILD 0004.1 LOGGER INTEGRATION: PASS`
