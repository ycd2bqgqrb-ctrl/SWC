/*
 * SWC Build 0004.1
 * Shelly Weather Controller
 * Integrated Foundation Logger 2.0
 */

var SWC = (function () {
  var LEVELS = {
    DEBUG: 10,
    INFO: 20,
    WARN: 30,
    ERROR: 40,
    FATAL: 50
  };

  var LEVEL_NAMES = {
    10: "DEBUG",
    20: "INFO",
    30: "WARN",
    40: "ERROR",
    50: "FATAL"
  };

  function normalizeLevel(level) {
    if (typeof level === "number") {
      return LEVEL_NAMES[level] ? level : LEVELS.INFO;
    }
    return LEVELS[String(level || "INFO").toUpperCase()] || LEVELS.INFO;
  }

  function serialize(value) {
    if (value === undefined) return "";
    if (value === null) return "null";
    if (value instanceof Error) {
      return JSON.stringify({
        name: value.name,
        message: value.message
      });
    }
    try {
      return JSON.stringify(value);
    } catch (e) {
      return "[Unserializable]";
    }
  }

  function write(line) {
    if (typeof print === "function") {
      print(line);
    } else if (typeof console !== "undefined" &&
               typeof console.log === "function") {
      console.log(line);
    }
  }

  function Logger(options) {
    options = options || {};
    this.name = options.name || "SWC";
    this.context = options.context || "";
    this.minLevel = normalizeLevel(options.minLevel || "INFO");
  }

  Logger.prototype.setLevel = function (level) {
    this.minLevel = normalizeLevel(level);
  };

  Logger.prototype.child = function (context) {
    return new Logger({
      name: this.name,
      context: this.context
        ? this.context + ":" + context
        : String(context),
      minLevel: this.minLevel
    });
  };

  Logger.prototype.log = function (level, message, data, code) {
    var numericLevel = normalizeLevel(level);

    if (numericLevel < this.minLevel) {
      return false;
    }

    var text = message instanceof Error
      ? message.message
      : (typeof message === "string" ? message : serialize(message));

    var line =
      "[" + new Date().toISOString() + "] " +
      "[" + LEVEL_NAMES[numericLevel] + "] ";

    if (this.context) {
      line += "[" + this.context + "] ";
    }

    if (code) {
      line += "[" + code + "] ";
    }

    line += text;

    if (data !== undefined) {
      line += " " + serialize(data);
    }

    write(line);
    return true;
  };

  Logger.prototype.debug = function (message, data, code) {
    return this.log("DEBUG", message, data, code);
  };

  Logger.prototype.info = function (message, data, code) {
    return this.log("INFO", message, data, code);
  };

  Logger.prototype.warn = function (message, data, code) {
    return this.log("WARN", message, data, code);
  };

  Logger.prototype.error = function (message, data, code) {
    return this.log("ERROR", message, data, code);
  };

  Logger.prototype.fatal = function (message, data, code) {
    return this.log("FATAL", message, data, code);
  };

  function boot() {
    var logger = new Logger({
      name: "SWC",
      context: "BOOT",
      minLevel: "DEBUG"
    });

    logger.info("SWC Build 0004.1 starting", undefined, "BOOT-0001");

    if (typeof Shelly !== "undefined") {
      logger.info("Shelly runtime detected", undefined, "HW-0001");
    } else {
      logger.warn(
        "Shelly runtime not detected",
        undefined,
        "HW-0002"
      );
    }

    logger.info(
      "Logger 2.0 integrated successfully",
      {
        levels: ["DEBUG", "INFO", "WARN", "ERROR", "FATAL"]
      },
      "LOG-0001"
    );

    logger.info(
      "Foundation boot completed",
      undefined,
      "BOOT-0002"
    );

    return logger;
  }

  return {
    Logger: Logger,
    boot: boot,
    LEVELS: LEVELS
  };
})();

var logger = SWC.boot();
