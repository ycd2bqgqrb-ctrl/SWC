/*
 * SWC Build 0004.1
 * Hardware integration test.
 */

var passed = 0;
var failed = 0;

function assertTest(name, condition) {
  if (condition) {
    passed++;
    print("PASS: " + name);
  } else {
    failed++;
    print("FAIL: " + name);
  }
}

print("SWC Build 0004.1 - Logger 2.0 integration test");
print("-----------------------------------------------");

var logger = new SWC.Logger({
  name: "TEST",
  context: "INTEGRATION",
  minLevel: "INFO"
});

assertTest("DEBUG filtered", logger.debug("hidden") === false);
assertTest("INFO accepted", logger.info("info", undefined, "T-001") === true);
assertTest("WARN accepted", logger.warn("warn", undefined, "T-002") === true);
assertTest("ERROR accepted", logger.error("error", undefined, "T-003") === true);
assertTest("FATAL accepted", logger.fatal("fatal", undefined, "T-004") === true);

var child = logger.child("CHILD");
assertTest("Child logger created", child.info("child", undefined, "T-005") === true);

print("-----------------------------------------------");
print("RESULT: " + passed + " passed, " + failed + " failed");

if (failed === 0) {
  print("BUILD 0004.1 LOGGER INTEGRATION: PASS");
} else {
  print("BUILD 0004.1 LOGGER INTEGRATION: FAIL");
}
