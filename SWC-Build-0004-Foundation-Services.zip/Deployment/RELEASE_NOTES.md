Build 0004 Testpaket.
