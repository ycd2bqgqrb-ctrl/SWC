Script ersetzen, speichern, starten.
